package com.gupaoedu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootMq0904Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootMq0904Application.class, args);
	}
}
